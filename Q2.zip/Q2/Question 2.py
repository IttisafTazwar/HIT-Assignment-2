import os
import csv
from pathlib import Path

def compute_monthly_average(folder_path):
    """Calculate the average temperature for each month across all data files."""
    monthly_sums = {month: 0 for month in range(1, 13)}
    monthly_counts = {month: 0 for month in range(1, 13)}

    for file in Path(folder_path).glob("*.csv"):
        with open(file, 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                month = int(row['Month'])
                temperature = float(row['Temperature'])
                monthly_sums[month] += temperature
                monthly_counts[month] += 1

    monthly_averages = {month: (monthly_sums[month] / monthly_counts[month]) for month in monthly_sums}

    with open('monthly_avg_temp.txt', 'w') as avg_file:
        for month, avg in monthly_averages.items():
            avg_file.write(f"Month {month}: {avg:.2f}\n")
    print("Monthly average temperatures saved to monthly_avg_temp.txt")
    return monthly_averages


def get_station_with_max_temperature_range(folder_path):
    """Identify the station(s) with the largest temperature range."""
    station_data = {}

    for file in Path(folder_path).glob("*.csv"):
        with open(file, 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                station = row['Station']
                temp = float(row['Temperature'])
                if station not in station_data:
                    station_data[station] = {'min': temp, 'max': temp}
                else:
                    station_data[station]['min'] = min(station_data[station]['min'], temp)
                    station_data[station]['max'] = max(station_data[station]['max'], temp)

    largest_range = 0
    stations_with_max_range = []
    for station, temps in station_data.items():
        range_diff = temps['max'] - temps['min']
        if range_diff > largest_range:
            largest_range = range_diff
            stations_with_max_range = [station]
        elif range_diff == largest_range:
            stations_with_max_range.append(station)

    with open('station_max_range.txt', 'w') as range_file:
        range_file.write(f"Largest Temperature Range: {largest_range:.2f}\n")
        range_file.write("Stations:\n")
        for station in stations_with_max_range:
            range_file.write(f"{station}\n")
    print("Stations with the largest temperature range saved to station_max_range.txt")


def find_extreme_temperature_stations(folder_path):
    """Find the stations with the highest and lowest average temperatures."""
    station_temps = {}

    for file in Path(folder_path).glob("*.csv"):
        with open(file, 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                station = row['Station']
                temp = float(row['Temperature'])
                if station not in station_temps:
                    station_temps[station] = {'total': temp, 'count': 1}
                else:
                    station_temps[station]['total'] += temp
                    station_temps[station]['count'] += 1

    station_averages = {station: temps['total'] / temps['count'] for station, temps in station_temps.items()}
    highest_temp = max(station_averages.values())
    lowest_temp = min(station_averages.values())

    hottest_stations = [station for station, avg in station_averages.items() if avg == highest_temp]
    coldest_stations = [station for station, avg in station_averages.items() if avg == lowest_temp]

    with open('extreme_stations.txt', 'w') as extremes_file:
        extremes_file.write(f"Highest Temperature: {highest_temp:.2f}\n")
        extremes_file.write("Hottest Stations:\n")
        for station in hottest_stations:
            extremes_file.write(f"{station}\n")
        extremes_file.write(f"\nLowest Temperature: {lowest_temp:.2f}\n")
        extremes_file.write("Coldest Stations:\n")
        for station in coldest_stations:
            extremes_file.write(f"{station}\n")
    print("Stations with the highest and lowest temperatures saved to extreme_stations.txt")


if __name__ == "__main__":
    folder_path = './temperature_data'  

    compute_monthly_average(folder_path)
    get_station_with_max_temperature_range(folder_path)
    find_extreme_temperature_stations(folder_path)
